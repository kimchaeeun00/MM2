package com.moneymate.controller;

import com.moneymate.entity.User;
import com.moneymate.service.UserService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/user")
public class UserRestController {

    private final UserService userService;

    public UserRestController(UserService userService) {
        this.userService = userService;
    }

    // 회원가입
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.register(user);
    }

    // 로그인
    @PostMapping("/login")
    public User login(@RequestBody User loginUser, HttpSession session) {

        User user = userService.login(loginUser.getUsername(), loginUser.getPassword());

        // ⭐ 로그인 성공하면 세션에 저장
        if (user != null) {
            session.setAttribute("loggedInUser", user);
        }

        return user; // 성공하면 user 반환, 실패하면 null
    }
}

